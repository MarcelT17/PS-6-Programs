# connect to the file

name = "Marcel"
salary = 0
sum1 = 0

file1 = open('Employee.txt','r')
for line in file1:
  name = file1.read(10)
  salary = int(file1.read(5))
if salary >= 100000.00:
  bonusrate = int(salary * (20/100))
elif salary == 50000:
  bonusrate = int(salary * (15/100))
else:
  bonusrate = int(salary * (10/100))
print(name+"'s salary is ,",salary,"and bonus is: ",bonusrate,"$")
sum1 += bonusrate
file1.close()  
print("sum of all bonuses paid out is:",sum1)